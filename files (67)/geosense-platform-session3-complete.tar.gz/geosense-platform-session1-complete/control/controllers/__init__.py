"""
Formation control algorithms for satellite constellations.

This module provides various control strategies for formation flying:
- LQR: Linear Quadratic Regulator for optimal control
- LQG: Linear Quadratic Gaussian combining LQR with Kalman filtering
- MPC: Model Predictive Control (coming soon)
- Station-keeping: Fuel-optimal maintenance strategies (coming soon)
"""

from .lqr import (
    solve_continuous_riccati,
    solve_discrete_riccati,
    lqr_gain_continuous,
    lqr_gain_discrete,
    hill_clohessy_wiltshire_matrices,
    FormationLQRController,
    compute_controllability_gramian,
    minimum_energy_control,
    design_formation_weights,
)

from .lqg import (
    kalman_filter_continuous,
    kalman_filter_discrete,
    LQGController,
    FormationLQGController,
)

__all__ = [
    # LQR functions
    'solve_continuous_riccati',
    'solve_discrete_riccati',
    'lqr_gain_continuous',
    'lqr_gain_discrete',
    'hill_clohessy_wiltshire_matrices',
    'FormationLQRController',
    'compute_controllability_gramian',
    'minimum_energy_control',
    'design_formation_weights',
    # LQG functions
    'kalman_filter_continuous',
    'kalman_filter_discrete',
    'LQGController',
    'FormationLQGController',
]
