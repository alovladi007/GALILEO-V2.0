#!/usr/bin/env python
"""
Quick test script to verify the synthetic data generator is working correctly.
"""

import sys
import numpy as np
from pathlib import Path

# Add project to path
sys.path.insert(0, '/home/claude')

def test_synthetic_generator():
    """Test the synthetic data generator with minimal configuration"""
    print("\n" + "="*60)
    print("TESTING SYNTHETIC DATA GENERATOR")
    print("="*60)
    
    try:
        # Import modules
        print("\n1. Importing modules...")
        from sim.synthetic import (
            SimulationConfig, 
            SatelliteConfig, 
            SyntheticDataGenerator,
            SubsurfaceModel
        )
        print("   ✓ Modules imported successfully")
        
        # Create minimal configuration
        print("\n2. Creating configuration...")
        sim_config = SimulationConfig(
            grid_size=(30, 30, 15),  # Small grid for quick test
            time_steps=10,            # Few time steps
            seed=42,                  # Deterministic
            noise_level=0.1
        )
        sat_config = SatelliteConfig()
        print("   ✓ Configuration created")
        
        # Test subsurface model
        print("\n3. Testing subsurface model...")
        subsurface = SubsurfaceModel(sim_config, seed=42)
        initial_density = subsurface.density_field.copy()
        
        # Add anomalies
        void = subsurface.add_void()
        tunnel = subsurface.add_tunnel()
        ore = subsurface.add_ore_body()
        
        # Verify anomalies were added
        assert len(subsurface.anomalies) == 3, "Wrong number of anomalies"
        assert not np.array_equal(initial_density, subsurface.density_field), "Density field unchanged"
        print(f"   ✓ Added {len(subsurface.anomalies)} anomalies")
        print(f"     - Void at {void.center}")
        print(f"     - Tunnel from {tunnel.shape_params['start']} to {tunnel.shape_params['end']}")
        print(f"     - Ore body at {ore.center}")
        
        # Test data generation
        print("\n4. Generating synthetic data...")
        generator = SyntheticDataGenerator(sim_config, sat_config)
        
        # Create output directory
        output_dir = Path("./test_output")
        output_dir.mkdir(exist_ok=True)
        
        # Generate data
        results = generator.generate(str(output_dir))
        
        print(f"   ✓ Data generated successfully")
        print(f"     - Simulation ID: {results['simulation_id']}")
        print(f"     - Telemetry shape: {results['telemetry_shape']}")
        print(f"     - Phase shape: {results['phase_shape']}")
        print(f"     - Anomalies: {len(results['anomalies'])}")
        
        # Verify output files exist
        print("\n5. Verifying output files...")
        required_files = [
            'telemetry_path', 'phase_path', 
            'collection_path', 'item_path', 'card_path'
        ]
        
        for file_key in required_files:
            file_path = Path(results[file_key])
            assert file_path.exists(), f"Missing file: {file_path}"
            file_size = file_path.stat().st_size
            print(f"   ✓ {file_path.name} ({file_size:,} bytes)")
        
        # Test data loading
        print("\n6. Testing data loading...")
        
        # Load telemetry
        import pandas as pd
        telemetry = pd.read_parquet(results['telemetry_path'])
        assert len(telemetry) > 0, "Empty telemetry data"
        print(f"   ✓ Loaded {len(telemetry)} telemetry records")
        
        # Load phase data
        phase_data = np.load(results['phase_path'])
        assert 'phases' in phase_data, "Missing phases in NPZ"
        assert 'noisy_phases' in phase_data, "Missing noisy_phases in NPZ"
        print(f"   ✓ Loaded phase arrays: {list(phase_data.keys())}")
        
        # Load metadata
        import json
        with open(results['collection_path'], 'r') as f:
            collection = json.load(f)
        assert collection['type'] == 'Collection', "Invalid STAC collection"
        print(f"   ✓ Loaded STAC collection: {collection['id']}")
        
        # Test determinism
        print("\n7. Testing determinism...")
        gen2 = SyntheticDataGenerator(sim_config, sat_config)
        output_dir2 = Path("./test_output2")
        output_dir2.mkdir(exist_ok=True)
        results2 = gen2.generate(str(output_dir2))
        
        # Load and compare
        data1 = np.load(results['phase_path'])
        data2 = np.load(results2['phase_path'])
        
        assert np.allclose(data1['phases'], data2['phases']), "Non-deterministic phases"
        print("   ✓ Deterministic output verified")
        
        # Summary
        print("\n" + "="*60)
        print("ALL TESTS PASSED!")
        print("="*60)
        print("\nThe synthetic data generator is working correctly.")
        print(f"Generated files are in: {output_dir}")
        
        return True
        
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        return False


def cleanup_test_files():
    """Clean up test output directories"""
    import shutil
    for dir_name in ['test_output', 'test_output2']:
        dir_path = Path(dir_name)
        if dir_path.exists():
            shutil.rmtree(dir_path)
            print(f"Cleaned up: {dir_path}")


if __name__ == "__main__":
    # Run tests
    success = test_synthetic_generator()
    
    # Optional cleanup
    if success:
        response = input("\nClean up test files? (y/n): ")
        if response.lower() == 'y':
            cleanup_test_files()
    
    sys.exit(0 if success else 1)
