'use client'

import { useState, useEffect } from 'react'
import dynamic from 'next/dynamic'
import { Navigation } from '@/components/Navigation'
import { TimeControls } from '@/components/TimeControls'
import { DataPanel } from '@/components/DataPanel'
import { JobConsole } from '@/components/JobConsole'
import { useAuth } from '@/hooks/useAuth'
import { useSatelliteData } from '@/hooks/useSatelliteData'
import { useGravityData } from '@/hooks/useGravityData'
import { format } from 'date-fns'
import toast from 'react-hot-toast'

// Dynamic import for Cesium to avoid SSR issues
const GlobeVisualization = dynamic(
  () => import('@/components/GlobeVisualization'),
  { 
    ssr: false,
    loading: () => (
      <div className="w-full h-full flex items-center justify-center">
        <div className="text-center">
          <div className="loading-spinner mx-auto mb-4" />
          <p className="text-slate-400">Loading globe visualization...</p>
        </div>
      </div>
    )
  }
)

export default function HomePage() {
  const { user, isAuthenticated } = useAuth()
  const [selectedTime, setSelectedTime] = useState(new Date())
  const [timeRange, setTimeRange] = useState({
    start: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), // 30 days ago
    end: new Date(),
  })
  const [selectedSatellites, setSelectedSatellites] = useState<string[]>(['GRACE-A', 'GRACE-B'])
  const [showGravityOverlay, setShowGravityOverlay] = useState(true)
  const [showUncertainty, setShowUncertainty] = useState(false)
  const [selectedRun, setSelectedRun] = useState<string | null>(null)
  const [isPlaying, setIsPlaying] = useState(false)
  const [playbackSpeed, setPlaybackSpeed] = useState(1)

  // Fetch satellite and gravity data
  const { data: satelliteData, isLoading: satelliteLoading } = useSatelliteData({
    satellites: selectedSatellites,
    time: selectedTime,
  })

  const { data: gravityData, isLoading: gravityLoading } = useGravityData({
    time: selectedTime,
    runId: selectedRun,
  })

  // Animation playback
  useEffect(() => {
    if (!isPlaying) return

    const interval = setInterval(() => {
      setSelectedTime(prevTime => {
        const newTime = new Date(prevTime.getTime() + 60000 * playbackSpeed) // 1 minute * speed
        if (newTime > timeRange.end) {
          setIsPlaying(false)
          return timeRange.start
        }
        return newTime
      })
    }, 100) // Update every 100ms

    return () => clearInterval(interval)
  }, [isPlaying, playbackSpeed, timeRange])

  const handleTimeChange = (newTime: Date) => {
    setSelectedTime(newTime)
  }

  const handlePlayPause = () => {
    setIsPlaying(!isPlaying)
  }

  const handleSpeedChange = (speed: number) => {
    setPlaybackSpeed(speed)
  }

  const handleSatelliteToggle = (satellite: string) => {
    setSelectedSatellites(prev =>
      prev.includes(satellite)
        ? prev.filter(s => s !== satellite)
        : [...prev, satellite]
    )
  }

  const handleRunCompare = (runId: string) => {
    if (selectedRun === runId) {
      setSelectedRun(null)
      toast.success('Run comparison disabled')
    } else {
      setSelectedRun(runId)
      toast.success(`Comparing with run ${runId.slice(0, 8)}...`)
    }
  }

  return (
    <div className="min-h-screen gradient-bg">
      <Navigation user={user} />
      
      <div className="flex h-[calc(100vh-64px)]">
        {/* Main Globe View */}
        <div className="flex-1 relative p-4">
          <div className="h-full rounded-xl overflow-hidden shadow-2xl">
            <GlobeVisualization
              satelliteData={satelliteData}
              gravityData={gravityData}
              showGravityOverlay={showGravityOverlay}
              showUncertainty={showUncertainty}
              selectedSatellites={selectedSatellites}
              selectedTime={selectedTime}
            />
            
            {/* Overlay Controls */}
            <div className="absolute top-4 left-4 space-y-2">
              <div className="glass-effect p-4">
                <h3 className="text-sm font-semibold mb-2">Visualization</h3>
                <div className="space-y-2">
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={showGravityOverlay}
                      onChange={(e) => setShowGravityOverlay(e.target.checked)}
                      className="rounded text-primary-600"
                    />
                    <span className="text-sm">Gravity Field</span>
                  </label>
                  <label className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      checked={showUncertainty}
                      onChange={(e) => setShowUncertainty(e.target.checked)}
                      className="rounded text-primary-600"
                    />
                    <span className="text-sm">Uncertainty</span>
                  </label>
                </div>
              </div>
              
              <div className="glass-effect p-4">
                <h3 className="text-sm font-semibold mb-2">Satellites</h3>
                <div className="space-y-2">
                  {['GRACE-A', 'GRACE-B', 'GRACE-FO-1', 'GRACE-FO-2'].map(sat => (
                    <label key={sat} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={selectedSatellites.includes(sat)}
                        onChange={() => handleSatelliteToggle(sat)}
                        className="rounded text-primary-600"
                      />
                      <span className="text-sm">{sat}</span>
                    </label>
                  ))}
                </div>
              </div>
            </div>
            
            {/* Legend */}
            {showGravityOverlay && (
              <div className="absolute top-4 right-4 glass-effect p-4">
                <h3 className="text-sm font-semibold mb-2">Gravity Anomaly (mGal)</h3>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-32 bg-gradient-to-t from-gravity-low via-gravity-medium to-gravity-high rounded" />
                  <div className="text-xs space-y-8">
                    <div>+50</div>
                    <div>0</div>
                    <div>-50</div>
                  </div>
                </div>
              </div>
            )}
          </div>
          
          {/* Time Controls */}
          <TimeControls
            selectedTime={selectedTime}
            timeRange={timeRange}
            isPlaying={isPlaying}
            playbackSpeed={playbackSpeed}
            onTimeChange={handleTimeChange}
            onPlayPause={handlePlayPause}
            onSpeedChange={handleSpeedChange}
          />
        </div>
        
        {/* Side Panel */}
        <div className="w-96 p-4 space-y-4 overflow-y-auto">
          <DataPanel
            selectedTime={selectedTime}
            satelliteData={satelliteData}
            gravityData={gravityData}
            onRunCompare={handleRunCompare}
            selectedRun={selectedRun}
          />
          
          {isAuthenticated && (
            <JobConsole />
          )}
        </div>
      </div>
    </div>
  )
}
