'use client'

import { useEffect, useRef, useState } from 'react'
import { Viewer, Entity, PolylineGraphics, BillboardGraphics, PathGraphics } from 'resium'
import * as Cesium from 'cesium'
import 'cesium/Build/Cesium/Widgets/widgets.css'

// Set Cesium Ion token if available
if (process.env.NEXT_PUBLIC_CESIUM_ION_TOKEN) {
  Cesium.Ion.defaultAccessToken = process.env.NEXT_PUBLIC_CESIUM_ION_TOKEN
}

interface SatelliteData {
  id: string
  position: {
    lat: number
    lon: number
    alt: number
  }
  velocity?: {
    x: number
    y: number
    z: number
  }
  gravity?: number
}

interface GravityData {
  grid: number[][]
  bounds: {
    north: number
    south: number
    east: number
    west: number
  }
  colorScale: {
    min: number
    max: number
  }
}

interface GlobeVisualizationProps {
  satelliteData?: SatelliteData[]
  gravityData?: GravityData
  showGravityOverlay: boolean
  showUncertainty: boolean
  selectedSatellites: string[]
  selectedTime: Date
}

export default function GlobeVisualization({
  satelliteData = [],
  gravityData,
  showGravityOverlay,
  showUncertainty,
  selectedSatellites,
  selectedTime,
}: GlobeVisualizationProps) {
  const viewerRef = useRef<Cesium.Viewer | null>(null)
  const [gravityImagery, setGravityImagery] = useState<Cesium.ImageryLayer | null>(null)
  
  // Initialize viewer settings
  const viewerOptions = {
    terrainProvider: Cesium.createWorldTerrain(),
    homeButton: false,
    sceneModePicker: false,
    baseLayerPicker: false,
    navigationHelpButton: false,
    animation: false,
    timeline: false,
    fullscreenButton: false,
    vrButton: false,
    geocoder: false,
    infoBox: false,
    selectionIndicator: false,
    shadows: true,
    shouldAnimate: true,
  }

  // Create gravity field overlay
  useEffect(() => {
    if (!viewerRef.current || !gravityData || !showGravityOverlay) {
      if (gravityImagery) {
        viewerRef.current?.imageryLayers.remove(gravityImagery)
        setGravityImagery(null)
      }
      return
    }

    // Create custom imagery provider for gravity data
    const gravityProvider = new Cesium.SingleTileImageryProvider({
      url: createGravityImage(gravityData),
      rectangle: Cesium.Rectangle.fromDegrees(
        gravityData.bounds.west,
        gravityData.bounds.south,
        gravityData.bounds.east,
        gravityData.bounds.north
      ),
    })

    const layer = viewerRef.current.imageryLayers.addImageryProvider(gravityProvider)
    layer.alpha = 0.6
    layer.colorToAlpha = new Cesium.Color(0, 0, 0, 0)
    
    setGravityImagery(layer)

    return () => {
      if (layer) {
        viewerRef.current?.imageryLayers.remove(layer)
      }
    }
  }, [gravityData, showGravityOverlay])

  // Generate gravity field image
  const createGravityImage = (data: GravityData): string => {
    const canvas = document.createElement('canvas')
    const width = data.grid[0].length
    const height = data.grid.length
    canvas.width = width
    canvas.height = height
    
    const ctx = canvas.getContext('2d')
    if (!ctx) return ''
    
    const imageData = ctx.createImageData(width, height)
    const { min, max } = data.colorScale
    const range = max - min
    
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const value = data.grid[y][x]
        const normalized = (value - min) / range
        const idx = (y * width + x) * 4
        
        // Color gradient: blue (low) -> green (medium) -> red (high)
        if (normalized < 0.5) {
          const t = normalized * 2
          imageData.data[idx] = Math.floor(0 * (1 - t) + 0 * t)     // R
          imageData.data[idx + 1] = Math.floor(0 * (1 - t) + 255 * t) // G
          imageData.data[idx + 2] = Math.floor(255 * (1 - t) + 0 * t) // B
        } else {
          const t = (normalized - 0.5) * 2
          imageData.data[idx] = Math.floor(0 * (1 - t) + 255 * t)     // R
          imageData.data[idx + 1] = Math.floor(255 * (1 - t) + 0 * t) // G
          imageData.data[idx + 2] = Math.floor(0 * (1 - t) + 0 * t)   // B
        }
        imageData.data[idx + 3] = 200 // Alpha
      }
    }
    
    ctx.putImageData(imageData, 0, 0)
    return canvas.toDataURL()
  }

  // Calculate baseline vectors between satellite pairs
  const getBaselineVectors = () => {
    const vectors: JSX.Element[] = []
    
    if (satelliteData.length >= 2) {
      for (let i = 0; i < satelliteData.length - 1; i++) {
        for (let j = i + 1; j < satelliteData.length; j++) {
          const sat1 = satelliteData[i]
          const sat2 = satelliteData[j]
          
          if (selectedSatellites.includes(sat1.id) && selectedSatellites.includes(sat2.id)) {
            const positions = [
              Cesium.Cartesian3.fromDegrees(sat1.position.lon, sat1.position.lat, sat1.position.alt * 1000),
              Cesium.Cartesian3.fromDegrees(sat2.position.lon, sat2.position.lat, sat2.position.alt * 1000),
            ]
            
            vectors.push(
              <Entity key={`baseline-${sat1.id}-${sat2.id}`}>
                <PolylineGraphics
                  positions={positions}
                  width={2}
                  material={Cesium.Color.YELLOW.withAlpha(0.8)}
                  arcType={Cesium.ArcType.NONE}
                />
              </Entity>
            )
          }
        }
      }
    }
    
    return vectors
  }

  return (
    <Viewer
      ref={(ref) => {
        if (ref?.cesiumElement) {
          viewerRef.current = ref.cesiumElement
        }
      }}
      full
      {...viewerOptions}
    >
      {/* Render satellites */}
      {satelliteData.map((satellite) => {
        if (!selectedSatellites.includes(satellite.id)) return null
        
        const position = Cesium.Cartesian3.fromDegrees(
          satellite.position.lon,
          satellite.position.lat,
          satellite.position.alt * 1000 // Convert km to meters
        )
        
        return (
          <Entity
            key={satellite.id}
            name={satellite.id}
            position={position}
            description={`
              <div>
                <h3>${satellite.id}</h3>
                <p>Latitude: ${satellite.position.lat.toFixed(3)}°</p>
                <p>Longitude: ${satellite.position.lon.toFixed(3)}°</p>
                <p>Altitude: ${satellite.position.alt.toFixed(1)} km</p>
                ${satellite.gravity ? `<p>Gravity: ${satellite.gravity.toFixed(6)} mGal</p>` : ''}
              </div>
            `}
          >
            <BillboardGraphics
              image="/satellite-icon.png"
              scale={0.5}
              horizontalOrigin={Cesium.HorizontalOrigin.CENTER}
              verticalOrigin={Cesium.VerticalOrigin.CENTER}
            />
            <PathGraphics
              leadTime={300}
              trailTime={600}
              width={3}
              material={Cesium.Color.CYAN.withAlpha(0.6)}
            />
          </Entity>
        )
      })}
      
      {/* Render baseline vectors */}
      {getBaselineVectors()}
    </Viewer>
  )
}
