# Satellite Gravity Processing System

## Overview
Complete backend and frontend implementation for satellite gravity data processing, featuring:
- **Backend**: FastAPI + Celery + PostgreSQL/TimescaleDB + MinIO
- **Frontend**: Next.js + CesiumJS + Deck.gl

## Quick Start

```bash
# Start all services
docker-compose up -d

# Backend API will be available at http://localhost:8000
# Frontend UI will be available at http://localhost:3000
# API Documentation at http://localhost:8000/docs
```

## Architecture

### Session 7 - Backend Ops
- FastAPI REST API with /plan, /ingest, /process, /catalog, /auth endpoints
- Celery workers for asynchronous batch processing
- PostgreSQL with TimescaleDB extension for time-series data
- MinIO object storage for raw data and products
- Comprehensive audit logging and provenance tracking

### Session 8 - Web UI
- Next.js 14 with TypeScript
- CesiumJS for 3D globe visualization
- Deck.gl for data overlays
- OAuth2 authentication
- Real-time job monitoring

## Testing

```bash
# Backend tests
cd ops && pytest

# Frontend tests
cd ui && npm test
cd ui && npx playwright test
```

## Documentation
- [Backend Operations Guide](docs/backend_ops.md)
- [Frontend UI Guide](docs/ui.md)
